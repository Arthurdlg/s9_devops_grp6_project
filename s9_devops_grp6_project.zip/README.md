# ST2DCE-PRJ-2324S9-SE1

## Bonus: Buildpacks vs Dockerfile
- Installed the Buildpack utility following the official [documentation](https://buildpacks.io/docs/for-platform-operators/how-to/integrate-ci/pack/).
